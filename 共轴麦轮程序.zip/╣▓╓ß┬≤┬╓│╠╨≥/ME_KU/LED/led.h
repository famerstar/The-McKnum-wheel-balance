#ifndef __LED_H
#define __LED_H	 
#include "sys.h"

#define LED0 PCout(13)// PB5





void LED_Init(void);//��ʼ��

		 				    
#endif
