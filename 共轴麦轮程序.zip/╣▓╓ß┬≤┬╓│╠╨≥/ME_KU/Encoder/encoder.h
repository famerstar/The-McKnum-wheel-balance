#ifndef __ENCODER_H
#define __ENCODER_H	 
#include "sys.h"


void Encoder_TIM2_Init(void);
void Encoder_TIM3_Init(void);
char Read_Speed(int TIMx);
#endif

