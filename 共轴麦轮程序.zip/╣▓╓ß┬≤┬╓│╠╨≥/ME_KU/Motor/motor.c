#include "motor.h"





void Motor_Control_Init(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
 	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);	
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;						
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 
	GPIO_Init(GPIOB, &GPIO_InitStructure);					 
	 
	GPIO_ResetBits(GPIOB,GPIO_Pin_13);	
	GPIO_SetBits(GPIOB,GPIO_Pin_12); 
}

void TIM4_PWM_Init(u16 arr,u16 psc)
{
	GPIO_InitTypeDef GPIO_InitStructure;  
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStrue;    
	TIM_OCInitTypeDef TIM_OCInitSture;    
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4,ENABLE); 
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF_PP;   
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8|GPIO_Pin_9;      
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStructure);     
	
	TIM_TimeBaseInitStrue.TIM_Period =arr ;       
	TIM_TimeBaseInitStrue.TIM_Prescaler =psc ;  
	TIM_TimeBaseInitStrue.TIM_CounterMode =TIM_CounterMode_Up;  
	TIM_TimeBaseInitStrue.TIM_ClockDivision =TIM_CKD_DIV1;     
	TIM_TimeBaseInit(TIM4,&TIM_TimeBaseInitStrue); 


	TIM_OCInitSture.TIM_OCMode = TIM_OCMode_PWM1;     
	TIM_OCInitSture.TIM_OutputState = TIM_OutputState_Enable;   
	TIM_OCInitSture.TIM_OCPolarity = TIM_OCPolarity_High;   
	TIM_OC1Init(TIM4, &TIM_OCInitSture); 
	
	TIM_OCInitSture.TIM_OCMode = TIM_OCMode_PWM1;     
	TIM_OCInitSture.TIM_OutputState = TIM_OutputState_Enable;   
	TIM_OCInitSture.TIM_OCPolarity = TIM_OCPolarity_High;   
	TIM_OC2Init(TIM4, &TIM_OCInitSture);
	
	TIM_OCInitSture.TIM_OCMode = TIM_OCMode_PWM1;     
	TIM_OCInitSture.TIM_OutputState = TIM_OutputState_Enable;   
	TIM_OCInitSture.TIM_OCPolarity = TIM_OCPolarity_High;   
	TIM_OC3Init(TIM4, &TIM_OCInitSture); 
	
	TIM_OCInitSture.TIM_OCMode = TIM_OCMode_PWM1;     
	TIM_OCInitSture.TIM_OutputState = TIM_OutputState_Enable;   
	TIM_OCInitSture.TIM_OCPolarity = TIM_OCPolarity_High;   
	TIM_OC4Init(TIM4, &TIM_OCInitSture); 
	
	TIM_OC1PreloadConfig(TIM4, TIM_OCPreload_Enable);    
	TIM_OC2PreloadConfig(TIM4, TIM_OCPreload_Enable); 
	TIM_OC3PreloadConfig(TIM4, TIM_OCPreload_Enable);    
	TIM_OC4PreloadConfig(TIM4, TIM_OCPreload_Enable);    
	
	TIM_Cmd(TIM4, ENABLE);  
}

