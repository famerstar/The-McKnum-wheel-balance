#ifndef __MOTOR_H
#define __MOTOR_H	 
#include "sys.h"


void TIM4_PWM_Init(u16 arr,u16 psc);
void Motor_Control_Init(void);

#endif


