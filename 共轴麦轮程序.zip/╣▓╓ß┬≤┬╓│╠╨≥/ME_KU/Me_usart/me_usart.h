#ifndef __MEUSART_H
#define __MEUSART_H	 
#include "sys.h"


void me_uart2_init(u32 bound);
void me_uart1_init(u32 bound);
#endif
